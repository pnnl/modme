# Changelog

For guidance on changelogs, read [Keep a Changelog](http://keepachangelog.com).
For guidance on versioning, read [Semantic Versioning](http://semver.org).

## [Unreleased]
### Added
### Changed
### Removed

This is the currently in development version of the ModME. This will be updated with all changes made to other versions.

## [1.0.0] - 2015-12-30
### Changed
- Added auto scaling when only a single task, row, or coloumn are in the condition
- Added placeholder into task list to force code to have that section as blank space and pretend a task is there 
  - ( this is for scaling reasons).
- Fixed bug where condition page would not allow for saving the configuration and instead saved {} data
  - Was caused by not removing the blanks having a slot to begin with and not removing them when opening the page	

## [1.0.0] - 2015-12-22
### Changed
- Got the MATB tasks to the same point as all other versions
